<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];
    
    // Set the recipient email address (your Gmail address)
    $to = "vanshsharma10604@gmail.com";
    
    // Set the email subject
    $subject = "Contact Form Submission from $name";
    
    // Compose the email message
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=utf-8\r\n";
    
    $message_body = "<html><body>";
    $message_body .= "<h2>Contact Form Submission</h2>";
    $message_body .= "<p><strong>Name:</strong> $name</p>";
    $message_body .= "<p><strong>Email:</strong> $email</p>";
    $message_body .= "<p><strong>Message:</strong></p>";
    $message_body .= "<p>$message</p>";
    $message_body .= "</body></html>";
    
    // Send the email
    if (mail($to, $subject, $message_body, $headers)) {
        echo "Thank you for your message. We will contact you soon.";
    } else {
        echo "Oops! Something went wrong. Please try again later.";
    }
}
?>
